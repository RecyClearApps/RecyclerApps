package com.example.recyclear.data.api

import com.example.recyclear.data.response.NewUserResponse
import com.example.recyclear.data.response.ValidateUserResponse
import retrofit2.Response

class ApiRepository (private val apiService: ApiService){
    suspend fun register (name: String, email: String, password: String, confirmPassword: String): NewUserResponse {
        return apiService.register(name,email, password, confirmPassword)
    }

    suspend fun login(email: String, password: String): ValidateUserResponse {
        return apiService.login(email, password)
    }
}