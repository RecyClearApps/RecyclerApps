package com.example.recyclear

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.recyclear.data.response.Article
import com.example.recyclear.data.response.ArticleResponse
import com.example.recyclear.databinding.ActivityDetailArticleBinding

class DetailArticleActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailArticleBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailArticleBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener {
            onBackPressed()
        }
        val article = intent.getParcelableExtra<Article>("DATA")

        if (article != null) {
            binding.tvTitle.text = article.title
            binding.tvDescription.text = article.desciption
            Glide.with(this).load(article.thumbnail).into(binding.ivThumbnail)
        }
    }
}