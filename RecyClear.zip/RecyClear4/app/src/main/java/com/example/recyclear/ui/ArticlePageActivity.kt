package com.example.recyclear.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.recyclear.R
import com.example.recyclear.data.response.ArticleResponse
import com.example.recyclear.databinding.ActivityArticlePageBinding

class ArticlePageActivity : AppCompatActivity() {
    private lateinit var binding: ActivityArticlePageBinding

    private var list = ArrayList<ArticleResponse>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityArticlePageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.bckButton.setOnClickListener {
            onBackPressed()
        }

    }
}