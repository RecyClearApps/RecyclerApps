package com.example.recyclear.ui.home

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import com.example.recyclear.ResultState
import com.example.recyclear.data.api.ApiService
import com.example.recyclear.data.response.ArticleResponse

class HomePageRepository constructor(
    private val apiService: ApiService,
){
    fun getArticle(): LiveData<ResultState<ArticleResponse>> = liveData {
        emit(ResultState.Loading)
        try {
            val response = apiService.getArticle(apikey = "")
            val article = response.data

            emit(ResultState.Success(response))
        }catch (e: Exception) {
            Log.d("ArticleRepository", "getArticle: ${e.message.toString()} ")
            emit(ResultState.Error(e.message.toString()))

        }

//        val localData: LiveData<ResultState<List<ArticleResponse>>> = getArticle()
    }
}