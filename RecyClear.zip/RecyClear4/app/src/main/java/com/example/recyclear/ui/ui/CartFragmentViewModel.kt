package com.example.recyclear.ui.ui

import androidx.lifecycle.ViewModel

class CartFragmentViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}