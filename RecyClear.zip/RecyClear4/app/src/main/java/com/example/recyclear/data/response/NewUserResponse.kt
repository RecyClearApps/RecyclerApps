package com.example.recyclear.data.response

import com.google.gson.annotations.SerializedName

data class NewUserResponse(

	@field:SerializedName("status")
	val status: String? = null,

	@field:SerializedName("info")
	val info: String? = null
)
