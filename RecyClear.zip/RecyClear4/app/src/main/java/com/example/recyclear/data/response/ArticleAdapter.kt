package com.example.recyclear.data.response

import android.annotation.SuppressLint
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclear.DetailArticleActivity
import com.example.recyclear.databinding.ItemCardhomeBinding

class ArticleAdapter():
    ListAdapter<DataItem, ArticleAdapter.ListViewHolder>(DIFF_CALLBACK) {

         private lateinit var onItemClickCallback: OnItemClickCallback


    inner class ListViewHolder(private val binding: ItemCardhomeBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(article: DataItem) {
            binding.titleArticle.text = article.title
            itemView.setOnClickListener { onItemClickCallback.onItemClicked(article) }
//            binding.buttonReadmore.setOnClickListener {
//                onItemClickCallback.onItemClicked
//            }
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): ArticleAdapter.ListViewHolder {
        val binding = ItemCardhomeBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ArticleAdapter.ListViewHolder, position: Int) {
        val article = getItem(position)
        holder.bind(article)
    }


    interface OnItemClickCallback {
        fun onItemClicked(data: DataItem)
    }

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    companion object {
        val DIFF_CALLBACK: DiffUtil.ItemCallback<DataItem> =
            object : DiffUtil.ItemCallback<DataItem>() {
                override fun areItemsTheSame(oldItem: DataItem, newItem: DataItem): Boolean {
                    return oldItem.title == newItem.title
                }
                @SuppressLint("DiffUtilEquals")
                override fun areContentsTheSame(oldItem: DataItem, newItem: DataItem): Boolean {
                    return oldItem == newItem
                }
            }
    }
}
