package com.example.recyclear.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.recyclear.data.response.ArticleResponse
import com.example.recyclear.data.response.DataItem
import kotlinx.coroutines.launch

class HomeViewModel(private val homePageRepository: HomePageRepository) : ViewModel() {
    private val _listArticle = MutableLiveData<List<ArticleResponse>>()
    val listArticle : LiveData<List<ArticleResponse>> = _listArticle

    fun getArticle() = homePageRepository.getArticle()

}