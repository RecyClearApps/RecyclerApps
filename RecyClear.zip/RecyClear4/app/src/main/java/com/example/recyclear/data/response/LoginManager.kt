package com.example.recyclear.data.response

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import java.util.concurrent.Flow

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "login_data")

class LoginManager(context: Context){

    private val dataStore = context.dataStore


    companion object {
        private val STRING_KEY_EMAIL = stringPreferencesKey("email")
        private val STRING_KEY_NAME = stringPreferencesKey("name")
        private val KEY_ACCESS_TOKEN = stringPreferencesKey("accessToken")
    }
    suspend fun saveLoginData(email:String, accessToken: String, name: String) {
        dataStore.edit { preferences ->
            preferences[STRING_KEY_EMAIL] = email
            preferences[STRING_KEY_NAME] = name
            preferences[KEY_ACCESS_TOKEN] = accessToken
        }
    }

    suspend fun clearLoginData(){
        dataStore.edit { preferences ->
            preferences.remove(STRING_KEY_NAME)
            preferences.remove(STRING_KEY_EMAIL)
            preferences.remove(KEY_ACCESS_TOKEN)
        }
    }

    val emailFlow: kotlinx.coroutines.flow.Flow<String?> = dataStore.data.map { preferences ->
        preferences[STRING_KEY_EMAIL]
    }

    val nameFlow: kotlinx.coroutines.flow.Flow<String?> = dataStore.data.map { preferences ->
        preferences[STRING_KEY_NAME]
    }

    val accessTokenFlow: kotlinx.coroutines.flow.Flow<String?> = dataStore.data.map { preferences ->
        preferences[KEY_ACCESS_TOKEN]
    }

    val isUserLoggin: kotlinx.coroutines.flow.Flow<Boolean> = dataStore.data.map { preferences ->
        preferences[STRING_KEY_EMAIL] != null && preferences[KEY_ACCESS_TOKEN] != null
    }
}