package com.example.recyclear.data.response

import android.os.Parcel
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Article (
    val title: String?,
    val desciption: String?,
    val thumbnail: String?,
) : Parcelable