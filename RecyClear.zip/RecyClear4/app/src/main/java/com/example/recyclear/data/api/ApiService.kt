package com.example.recyclear.data.api

import com.example.recyclear.data.response.ArticleResponse
import com.example.recyclear.data.response.DataItem
import com.example.recyclear.data.response.NewUserResponse
import com.example.recyclear.data.response.ValidateUserResponse
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Query

interface ApiService {

    @FormUrlEncoded
    @POST("register")
    suspend fun register(
        @Field("name") name: String,
        @Field("email") email: String,
        @Field("password") password: String,
        @Field("confirm password") confirmPassword: String,
    ): NewUserResponse

    @FormUrlEncoded
    @POST("login")
    suspend fun login(
        @Field("email") email: String,
        @Field("password") password: String
    ): ValidateUserResponse

    @GET("article")
    suspend fun getArticle(
        @Query("apikey") apikey: String
    ): ArticleResponse
}