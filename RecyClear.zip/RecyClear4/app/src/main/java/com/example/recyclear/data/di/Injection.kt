package com.example.recyclear.data.di

import android.content.Context
import com.example.recyclear.data.api.ApiConfig
import com.example.recyclear.ui.home.HomePageRepository

object Injection {
    fun provideRepository(context: Context): HomePageRepository{
        val apiService = ApiConfig.apiServiceGet(token = "BUFFa7hkosw9WXMJk2gANem5DpnIgicUFEoMMIEY")
        return HomePageRepository(apiService)
    }
}