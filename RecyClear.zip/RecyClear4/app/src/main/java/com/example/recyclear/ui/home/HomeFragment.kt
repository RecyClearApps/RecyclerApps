package com.example.recyclear.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.recyclear.DetailArticleActivity
import com.example.recyclear.ResultState
import com.example.recyclear.data.ViewModelFactory
import com.example.recyclear.data.response.Article
import com.example.recyclear.data.response.ArticleAdapter
import com.example.recyclear.data.response.ArticleResponse
import com.example.recyclear.data.response.DataItem
import com.example.recyclear.databinding.FragmentHomeBinding
import com.example.recyclear.ui.ArticlePageActivity


class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private val list = ArrayList<ArticleResponse>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val view = binding.root

//        list.addAll(getlist())
//        showRecyclerList()
        return view
    }

//    private fun showRecyclerList() {
//        binding.rvListhome.layoutManager = LinearLayoutManager(context)
//        val articleAdapter = ArticleAdapter(list)
//        binding.rvListhome.adapter = articleAdapter
//    }

//    private fun getlist(): Collection<DataItem> {
//        val title = resources.getStringArray(R.array.title)
//        val listArticle = ArrayList<DataItem>()
//        return listArticle
//    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val factory: ViewModelFactory = ViewModelFactory.getIntance(requireActivity())
        val viewModel: HomeViewModel by viewModels { factory }

        binding.rvListhome.apply {
            layoutManager = LinearLayoutManager(context)
            setHasFixedSize(true)
        }

        binding.btnArticle.setOnClickListener {
            val intent = Intent(requireActivity().application, ArticlePageActivity::class.java)
            startActivity(intent)
        }


        viewModel.getArticle().observe(viewLifecycleOwner) { result ->
            if (result != null) {
                when (result) {
                    is ResultState.Loading -> {

                    }

                    is ResultState.Success -> {
                        val articleAdapter = ArticleAdapter()
//                        articleAdapter.onItemClickCallback.onItemClicked = {data ->
//                            startActivity(Intent(activity, DetailArticleActivity::class.java))
//                        }
                        articleAdapter.setOnItemClickCallback(object : ArticleAdapter.OnItemClickCallback {
                            override fun onItemClicked(data: DataItem) {
                                val intentToDetail = Intent(requireContext(), DetailArticleActivity::class.java)
                                intentToDetail.putExtra("DATA", Article(data.title, data.description, data.thumbnail))
                                startActivity(intentToDetail)
                            }
                        })
                        articleAdapter.submitList(result.data.data)
                        binding.rvListhome.adapter = articleAdapter
                    }

                    is ResultState.Error -> {
                        Toast.makeText(
                            context,
                            "Terjadi Kesalahan" + result.error,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }
    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}