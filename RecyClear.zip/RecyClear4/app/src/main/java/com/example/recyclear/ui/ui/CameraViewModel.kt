package com.example.recyclear.ui.ui

import androidx.lifecycle.ViewModel

class CameraViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}